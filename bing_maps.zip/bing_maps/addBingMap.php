<?php

$str = ($_SERVER['QUERY_STRING']);
if (substr($str, -16) != 'user/1/maps/bing')
{		
	?>
	<script type="text/javascript">

	var adminwidth = '';
	var adminheight = '';
	var adminZoomLevel = ''; 
	var adminDefaultLocation = '';
	
	//Set these variables to change beginning map location
	var beginLatitude = 47.6;
	var beginLongitude = -122.33;
	var beginZoom = 10;
	var beginMapType = 'h';

	var title = new Array();
	var description = new Array();
	var locationss = new Array();

	var app;
	var clearIdent="";
	
	
	function showMap()
	{
		//fetchAdminData();

		/*
		if(height == null || height == '' || height == 'height')
		{
			if(adminheight != null && adminheight != '')
				height = adminheight;
			else
				height = 500;
		}
	
		if(width == null || width == '' || width == 'width')
		{
			if(adminwidth != null && adminwidth != '')
				width = adminwidth;
			else
				width = 500;
		}
		
		if(zoomlevel == null || zoomlevel == '' || zoomlevel == 'zoomlevel')
		{
			if(adminZoomLevel != null && adminZoomLevel != '')
				beginZoom = adminZoomLevel;
			else
				beginZoom = 10;
		}
		else
		{
			beginZoom = zoomlevel;
		}
		if(defaultLocation == null || defaultLocation == '' || defaultLocation == 'defaultLocation')
		{
			if(adminDefaultLocation != null && adminDefaultLocation != '')
				defaultLocation = adminDefaultLocation;
			else
			{
				defaultLocation = 'seattle, wa';
			}
		}

		*/
		
		if(direction == null || direction == '')
		{
			var from = '';
			var to = '';
		}
		else
		{
			var dir = direction.split(";");
			if(dir[0] == null || dir[0] == '' || dir[1] == null || dir[1] == '')
			{
				alert('Either \'from\' or \'to\' is not defined');
				return false;
			}
			else
			{
				var from = dir[0];
				var to = dir[1];
			}
		}
				
		if(pushpins.length>0)
		{
			var pins = pushpins.split("|");
		
			//do a foreach of all the pushpin details
			for(var i=0;i<pins.length;i++)
			{
				var pindetails = pins[i].split(";");
	
				if(pindetails.length < 3)
				{
					alert('Location details missing.');
					return true;
				}
				else
				{
					title[i] = pindetails[0];
					description[i] = pindetails[1];
					locationss[i] = pindetails[2];
				}
			}
		}
				if(jQuery("#bingmap").length > 0 || jQuery("#BingMap").length > 0)
				{	
					<?php 
						
						$bingObj->displayMap();
					?>
					
					if((from != null && from != '') || (to != null && to != ''))
					{
					<?php
						$bingObj->showDirections('from', 'to'); 
					?>
					}

					app=0;
					clearIdent = setInterval('checkWait()', 2000);

					//GotoUserLocation(defaultLocation);

				}	
				
	}

	function checkWait()
	{
		if(app==locationss.length)
		{			
			clearInterval(clearIdent);
			return;
		}
			if(waitingForCallback)
			{
				FindAndAddPin('', title[app], description[app], locationss[app]);
				app++;
			}
	}

	function fetchAdminData()
	{

	}
	
	</script>
<?php 
}
?>
